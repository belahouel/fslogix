configuration FslogixConfiguration
{
    param
    (
        [Parameter(Mandatory=$true)]
        [string]$connectionString
    )

    $LocalWVDpath = "c:\temp\wvd\"
    $FSLogixURI  = "https://aka.ms/fslogix_download"
    $FSInstaller = "FSLogixAppsSetup.zip"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12


    # part 2
    if((Test-Path c:\temp) -eq $false) {
        Add-Content -LiteralPath C:\New-WVDSessionHost.log "Create C:\temp Directory"
        Write-Host `
            -ForegroundColor Cyan `
            -BackgroundColor Black `
            "creating temp directory"
        New-Item -Path c:\temp -ItemType Directory
    }
    else {
        Add-Content -LiteralPath C:\New-WVDSessionHost.log "C:\temp Already Exists"
        Write-Host `
            -ForegroundColor Yellow `
            -BackgroundColor Black `
            "temp directory already exists"
    }
    if((Test-Path $LocalWVDpath) -eq $false) {
        Add-Content -LiteralPath C:\New-WVDSessionHost.log "Create C:\temp\WVD Directory"
        Write-Host `
            -ForegroundColor Cyan `
            -BackgroundColor Black `
            "creating c:\temp\wvd directory"
        New-Item -Path $LocalWVDpath -ItemType Directory
    }
    else {
        Add-Content -LiteralPath C:\New-WVDSessionHost.log "C:\temp\WVD Already Exists"
        Write-Host `
            -ForegroundColor Yellow `
            -BackgroundColor Black `
            "c:\temp\wvd directory already exists"
    }
    Add-Content `
    -LiteralPath C:\New-WVDSessionHost.log `
    "
    ProfilePath       = $connectionString
    "

    # part 3
    Add-Content -LiteralPath C:\New-WVDSessionHost.log "Downloading FSLogix"
        Invoke-WebRequest -Uri $FSLogixURI -OutFile "$LocalWVDpath$FSInstaller"


    # part 4
    Add-Content -LiteralPath C:\New-WVDSessionHost.log "Unzip FSLogix"
    Expand-Archive `
        -LiteralPath "C:\temp\wvd\$FSInstaller" `
        -DestinationPath "$LocalWVDpath\FSLogix" `
        -Force `
        -Verbose
    cd $LocalWVDpath 
    Add-Content -LiteralPath C:\New-WVDSessionHost.log "UnZip FXLogix Complete"


    # part 5
    Add-Content -LiteralPath C:\New-WVDSessionHost.log "Installing FSLogix"
    $fslogix_deploy_status = Start-Process `
        -FilePath "$LocalWVDpath\FSLogix\x64\Release\FSLogixAppsSetup.exe" `
        -ArgumentList "/install /quiet" `
        -Wait `
        -Passthru


    # part 6
    Add-Content -LiteralPath C:\New-WVDSessionHost.log "Configure FSLogix Profile Settings"
    Push-Location 
    Set-Location HKLM:\SOFTWARE\
    New-Item `
        -Path HKLM:\SOFTWARE\FSLogix `
        -Name Profiles `
        -Value "" `
        -Force
    New-Item `
        -Path HKLM:\Software\FSLogix\Profiles\ `
        -Name Apps `
        -Force
    Set-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "Enabled" `
        -Type "Dword" `
        -Value "1"
    New-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "VHDLocations" `
        -Value $connectionString `
        -PropertyType MultiString `
        -Force
    Set-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "SizeInMBs" `
        -Type "Dword" `
        -Value "30720"
    Set-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "IsDynamic" `
        -Type "Dword" `
        -Value "1"
    Set-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "VolumeType" `
        -Type String `
        -Value "vhdx"
    Set-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "ConcurrentUserSessions" `
        -Type "Dword" `
        -Value "1"
    Set-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "FlipFlopProfileDirectoryName" `
        -Type "Dword" `
        -Value "1" 
    Set-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "SIDDirNamePattern" `
        -Type String `
        -Value "%username%%sid%"
    Set-ItemProperty `
        -Path HKLM:\Software\FSLogix\Profiles `
        -Name "SIDDirNameMatch" `
        -Type String `
        -Value "%username%%sid%" 
    New-ItemProperty `
        -Path HKLM:\SOFTWARE\FSLogix\Profiles `
        -Name "DeleteLocalProfileWhenVHDShouldApply" `
        -PropertyType "DWord" `
        -Value 1
    Pop-Location


    # part 7
    Add-Content -LiteralPath C:\New-WVDSessionHost.log "Process Complete - REBOOT"
    Restart-Computer -Force

}