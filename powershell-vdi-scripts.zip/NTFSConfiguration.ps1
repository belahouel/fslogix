configuration NTFSConfiguration
{
    param
    (
        [Parameter(Mandatory=$true)]
        [string]$StorageAccountName,
        [Parameter(Mandatory=$true)]
        [string]$AzufileShareName,
        [Parameter(Mandatory=$true)]
        [string]$StorageAccountKey,
        [Parameter(Mandatory=$true)]
        [string]$ADDSname,
        [Parameter(Mandatory=$true)]
        [string]$UserGroupName,
        [Parameter(Mandatory=$true)]
        [string]$AdminGroupName
    )

    #Step 3
    #Variable to not modify
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $DirectoryID= "T:\Profiles"
    $Directory= "Profiles"

    #Step 5
    #  Run the code below to test the connection and mount the share
    $connectTestResult = Test-NetConnection -ComputerName "$StorageAccountName.file.core.windows.net" -Port 445
    if ($connectTestResult.TcpTestSucceeded)
    {
      net use T: "\\$StorageAccountName.file.core.windows.net\$AzufileShareName" /user:Azure\$StorageAccountName $StorageAccountKey
    } 
    else 
    {
      Write-Error -Message "Unable to reach the Azure storage account via port 445. Check to make sure your organization or ISP is not blocking port 445, or use Azure P2S VPN,   Azure S2S VPN, or Express Route to tunnel SMB traffic over a different port."
    }

    #Step 6 Directory and NTFS
    New-Item -Path $DirectoryID -ItemType Directory

    #Set the NTFS Right
    icacls \\$StorageAccountName.file.core.windows.net\$AzufileShareName\$Directory /inheritance:d
    icacls \\$StorageAccountName.file.core.windows.net\$AzufileShareName\$Directory /remove "Creator Owner"
    icacls \\$StorageAccountName.file.core.windows.net\$AzufileShareName\$Directory /grant 'CREATOR OWNER:(OI)(CI)(IO)(M)'
    icacls \\$StorageAccountName.file.core.windows.net\$AzufileShareName\$Directory /remove "Authenticated Users" 
    icacls \\$StorageAccountName.file.core.windows.net\$AzufileShareName\$Directory /remove "Builtin\Users"
    icacls \\$StorageAccountName.file.core.windows.net\$AzufileShareName\$Directory /grant $ADDSname\"$UserGroupName":M
    icacls \\$StorageAccountName.file.core.windows.net\$AzufileShareName\$Directory /grant $ADDSname\"$AdminGroupName":F

}